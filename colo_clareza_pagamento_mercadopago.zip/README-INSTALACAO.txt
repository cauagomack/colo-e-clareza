COLO & CLAREZA — INTEGRAÇÃO DE PAGAMENTO (R$ 69,90)

O QUE ESTE PACOTE FAZ
- Mantém o mapa gratuito.
- Cobra apenas ao clicar em "Solicitar análise".
- Cria o Checkout Pro no backend da Vercel.
- Confirma status, valor (R$ 69,90), moeda e referência do pagamento.
- Só libera o formulário depois da aprovação.
- Exige um token assinado no Google Apps Script.
- Permite um único envio por pagamento.
- Mantém Drive e Google Planilhas.
- Mantém a devolutiva em até 24 horas.

ARQUIVOS PARA O STACKBLITZ/GITHUB
- Substitua src/Mapa.jsx
- Substitua src/Mapa.css
- Substitua src/SendForAnalysisModal.jsx
- Crie src/paymentApi.js
- Crie a pasta api na raiz e adicione:
  - api/_paymentShared.js
  - api/create-preference.js
  - api/payment-status.js
  - api/mercadopago-webhook.js
- Substitua package.json
- App.jsx não muda, mas está incluído como referência.

GOOGLE APPS SCRIPT
1. No Code.gs incluído, coloque os IDs REAIS atuais em:
   DRIVE_FOLDER_ID
   SPREADSHEET_ID
2. No Apps Script, abra Configurações do projeto > Propriedades do script.
3. Crie:
   BACKEND_SHARED_SECRET = uma senha aleatória longa
   SUBMISSION_TOKEN_SECRET = outra senha aleatória longa
4. Os dois valores precisam ser iguais aos configurados na Vercel.
5. Substitua o Code.gs atual pelo novo.
6. Implantar > Gerenciar implantações > Editar > Nova versão > Implantar.
7. Mantenha a mesma URL /exec.

VERCEL — VARIÁVEIS DE AMBIENTE
Em Settings > Environment Variables, crie para Preview e Production:

MERCADO_PAGO_ACCESS_TOKEN
MERCADO_PAGO_WEBHOOK_SECRET
CHECKOUT_TOKEN_SECRET
SUBMISSION_TOKEN_SECRET
BACKEND_SHARED_SECRET
APPS_SCRIPT_URL
SITE_URL=https://colo-e-clareza.vercel.app
ANALYSIS_PRICE=69.90
MERCADO_PAGO_MODE=test

- CHECKOUT_TOKEN_SECRET: gere uma senha aleatória longa.
- SUBMISSION_TOKEN_SECRET: deve ser igual à propriedade do Apps Script.
- BACKEND_SHARED_SECRET: deve ser igual à propriedade do Apps Script.
- APPS_SCRIPT_URL: use a URL atual terminada em /exec.
- Nunca coloque essas chaves dentro de src ou no GitHub.

MERCADO PAGO
1. Crie/abra uma aplicação em Suas integrações.
2. Em credenciais de teste, copie o Access Token para MERCADO_PAGO_ACCESS_TOKEN.
3. Em Webhooks, configure a URL de teste:
   https://colo-e-clareza.vercel.app/api/mercadopago-webhook
4. Ative o evento Pagamentos (payment).
5. Copie a assinatura secreta do Webhook para MERCADO_PAGO_WEBHOOK_SECRET.
6. Mantenha MERCADO_PAGO_MODE=test durante os testes.

APÓS CONFIGURAR
1. Faça commit e push.
2. Na Vercel, faça novo deploy. Variáveis novas só valem em novos deploys.
3. Monte e conclua um mapa.
4. Clique em Solicitar análise.
5. Faça um pagamento de teste.
6. Ao voltar, o backend validará o pagamento e abrirá o formulário.
7. Após o envio, confira:
   - imagem no Drive;
   - linha na aba Envios;
   - linha na aba Pagamentos marcada como Utilizado = Sim.

PRODUÇÃO
Somente depois dos testes:
- troque MERCADO_PAGO_ACCESS_TOKEN pela credencial de produção;
- configure o Webhook em modo produção;
- troque MERCADO_PAGO_WEBHOOK_SECRET pela assinatura de produção;
- altere MERCADO_PAGO_MODE para production;
- faça novo deploy.

IMPORTANTE
O Code.gs recebido nesta conversa mostrava IDs como COLE_AQUI. Se isso foi apenas ocultado ao copiar, mantenha os IDs reais da versão que já funciona. Não publique com os placeholders.
