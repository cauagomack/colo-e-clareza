const CHECKOUT_CONTEXT_KEY = 'colo-clareza-checkout-context-v1';

async function readJsonResponse(response) {
  const result = await response.json().catch(() => null);
  if (!response.ok || !result) {
    const error = new Error(result?.error || 'O servidor não respondeu como esperado.');
    error.paymentStatus = result?.paymentStatus;
    throw error;
  }
  return result;
}

export async function startAnalysisPayment() {
  const response = await fetch('/api/create-preference', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ service: 'systemic-analysis' }),
  });

  const result = await readJsonResponse(response);

  window.localStorage.setItem(
    CHECKOUT_CONTEXT_KEY,
    JSON.stringify({
      checkoutToken: result.checkoutToken,
      externalReference: result.externalReference,
      createdAt: Date.now(),
    }),
  );

  return result;
}

function readCheckoutContext() {
  return JSON.parse(window.localStorage.getItem(CHECKOUT_CONTEXT_KEY) || 'null');
}

function writeCheckoutContext(context) {
  window.localStorage.setItem(CHECKOUT_CONTEXT_KEY, JSON.stringify(context));
}

export async function verifyReturnedPayment(paymentId) {
  const saved = readCheckoutContext();
  if (!saved?.checkoutToken) {
    throw new Error('Não encontrei a sessão deste pagamento neste navegador.');
  }

  const response = await fetch(
    `/api/payment-status?payment_id=${encodeURIComponent(paymentId)}`,
    {
      headers: {
        'x-checkout-token': saved.checkoutToken,
      },
    },
  );

  const result = await readJsonResponse(response);
  writeCheckoutContext({ ...saved, paymentId: String(paymentId), verifiedAt: Date.now() });
  return result;
}

export async function resumeAnalysisPayment() {
  const saved = readCheckoutContext();
  if (!saved?.paymentId || !saved?.checkoutToken) return null;
  return verifyReturnedPayment(saved.paymentId);
}

export function clearCheckoutContext() {
  window.localStorage.removeItem(CHECKOUT_CONTEXT_KEY);
}
