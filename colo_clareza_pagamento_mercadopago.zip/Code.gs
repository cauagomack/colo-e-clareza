/**
 * Colo & Clareza — Drive, Planilhas e validação do pagamento.
 * IMPORTANTE: mantenha os IDs reais da sua pasta e planilha.
 */
const CONFIG = {
  DRIVE_FOLDER_ID: 'COLE_AQUI_O_ID_REAL_DA_PASTA_DO_DRIVE',
  SPREADSHEET_ID: 'COLE_AQUI_O_ID_REAL_DA_PLANILHA',
  SHEET_NAME: 'Envios',
  PAYMENTS_SHEET_NAME: 'Pagamentos',
  MAX_IMAGE_SIZE_MB: 4,
  MIN_SECONDS_BETWEEN_SUBMISSIONS: 30,
  ANALYSIS_AMOUNT: 69.90,
  ANALYSIS_CURRENCY: 'BRL',
};

const SUBMISSION_HEADERS = [
  'Data',
  'Nome',
  'Contato',
  'Mensagem',
  'Link da imagem',
  'Status',
  'Pagamento',
  'ID do pagamento',
  'Referência do pedido',
];

const PAYMENT_HEADERS = [
  'ID do pagamento',
  'Referência do pedido',
  'Status',
  'Valor',
  'Moeda',
  'Última atualização',
  'Utilizado',
  'Data de uso',
];

function doGet() {
  return ContentService.createTextOutput('OK').setMimeType(ContentService.MimeType.TEXT);
}

function doPost(e) {
  try {
    const payload = parseRequestBody(e);
    const action = String(payload.action || 'submitMap');

    if (action === 'registerPayment') {
      return handleRegisterPayment(payload);
    }

    if (action === 'submitMap') {
      return handleSubmitMap(payload);
    }

    return respond({ success: false, error: 'Ação desconhecida.' });
  } catch (error) {
    return respond({ success: false, error: 'Erro interno: ' + error.message });
  }
}

function handleRegisterPayment(payload) {
  requireBackendSecret(payload.backendSecret);

  const paymentId = String(payload.paymentId || '').trim();
  const externalReference = String(payload.externalReference || '').trim();
  const paymentStatus = String(payload.paymentStatus || '').trim();
  const amount = Number(payload.amount);
  const currency = String(payload.currency || '').trim();

  if (!paymentId || !externalReference || !paymentStatus) {
    throw new Error('Dados do pagamento incompletos.');
  }
  if (Math.abs(amount - CONFIG.ANALYSIS_AMOUNT) > 0.001) {
    throw new Error('Valor do pagamento inválido.');
  }
  if (currency !== CONFIG.ANALYSIS_CURRENCY) {
    throw new Error('Moeda do pagamento inválida.');
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    upsertPayment({
      paymentId: paymentId,
      externalReference: externalReference,
      status: paymentStatus,
      amount: amount,
      currency: currency,
      updatedAt: payload.updatedAt ? new Date(payload.updatedAt) : new Date(),
    });
  } finally {
    lock.releaseLock();
  }

  return respond({ success: true });
}

function handleSubmitMap(payload) {
  if (payload.honeypot && String(payload.honeypot).trim() !== '') {
    return respond({ success: true });
  }

  const tokenData = verifySubmissionToken(String(payload.submissionToken || ''));
  const name = String(payload.name || '').trim();
  const contact = String(payload.contact || '').trim();
  const message = String(payload.message || '').trim();
  const imageBase64 = String(payload.imageBase64 || '');

  if (!name) return respond({ success: false, error: 'Nome não informado.' });
  if (!contact) return respond({ success: false, error: 'Contato não informado.' });
  if (!imageBase64) return respond({ success: false, error: 'Imagem do mapa não recebida.' });

  const base64Data = imageBase64.indexOf('base64,') >= 0
    ? imageBase64.split('base64,')[1]
    : imageBase64;

  const approxSizeMb = (base64Data.length * 0.75) / (1024 * 1024);
  if (approxSizeMb > CONFIG.MAX_IMAGE_SIZE_MB) {
    return respond({
      success: false,
      error: 'Imagem maior que o limite permitido (' + CONFIG.MAX_IMAGE_SIZE_MB + 'MB).',
    });
  }

  const cache = CacheService.getScriptCache();
  const cacheKey = 'ultimo-envio-' + contact.toLowerCase();
  if (cache.get(cacheKey)) {
    return respond({
      success: false,
      error: 'Envio recente detectado. Aguarde alguns segundos e tente novamente.',
    });
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);

  try {
    const payment = findPayment(tokenData.paymentId);
    if (!payment) throw new Error('Pagamento não encontrado. Atualize a página e tente novamente.');
    if (String(payment.status).toLowerCase() !== 'approved') {
      throw new Error('O pagamento ainda não está aprovado.');
    }
    if (String(payment.used).toLowerCase() === 'sim') {
      throw new Error('Este pagamento já foi utilizado para outro envio.');
    }
    if (payment.externalReference !== tokenData.externalReference) {
      throw new Error('A referência do pagamento não corresponde ao envio.');
    }

    const imageUrl = saveImageToDrive(base64Data, name);
    appendSubmission({
      date: new Date(),
      name: name,
      contact: contact,
      message: message,
      imageUrl: imageUrl,
      status: 'Novo',
      paymentStatus: 'Aprovado',
      paymentId: tokenData.paymentId,
      externalReference: tokenData.externalReference,
    });
    markPaymentUsed(payment.row);
    cache.put(cacheKey, '1', CONFIG.MIN_SECONDS_BETWEEN_SUBMISSIONS);

    return respond({ success: true, imageUrl: imageUrl });
  } finally {
    lock.releaseLock();
  }
}

function parseRequestBody(e) {
  if (!e || !e.postData || !e.postData.contents) {
    throw new Error('Corpo da requisição vazio.');
  }
  return JSON.parse(e.postData.contents);
}

function requireBackendSecret(receivedSecret) {
  const expected = PropertiesService.getScriptProperties().getProperty('BACKEND_SHARED_SECRET');
  if (!expected || !constantTimeEquals(String(receivedSecret || ''), expected)) {
    throw new Error('Acesso de backend não autorizado.');
  }
}

function verifySubmissionToken(token) {
  const secret = PropertiesService.getScriptProperties().getProperty('SUBMISSION_TOKEN_SECRET');
  if (!secret) throw new Error('SUBMISSION_TOKEN_SECRET não configurado.');

  const parts = token.split('.');
  if (parts.length !== 2) throw new Error('Token de envio inválido.');

  const encoded = parts[0];
  const receivedSignature = parts[1];
  const expectedSignature = bytesToHex(
    Utilities.computeHmacSha256Signature(encoded, secret, Utilities.Charset.UTF_8),
  );

  if (!constantTimeEquals(receivedSignature, expectedSignature)) {
    throw new Error('Assinatura do envio inválida.');
  }

  const payloadJson = Utilities.newBlob(
    Utilities.base64DecodeWebSafe(addBase64Padding(encoded)),
  ).getDataAsString();
  const payload = JSON.parse(payloadJson);

  if (payload.kind !== 'submission') throw new Error('Tipo de token inválido.');
  if (!payload.exp || Number(payload.exp) < Math.floor(Date.now() / 1000)) {
    throw new Error('A autorização para envio expirou. Confirme o pagamento novamente.');
  }
  if (Math.abs(Number(payload.amount) - CONFIG.ANALYSIS_AMOUNT) > 0.001) {
    throw new Error('Valor autorizado inválido.');
  }
  if (payload.currency !== CONFIG.ANALYSIS_CURRENCY) {
    throw new Error('Moeda autorizada inválida.');
  }

  return payload;
}

function saveImageToDrive(base64Data, name) {
  const folder = DriveApp.getFolderById(CONFIG.DRIVE_FOLDER_ID);
  const bytes = Utilities.base64Decode(base64Data);
  const timestamp = Utilities.formatDate(
    new Date(),
    Session.getScriptTimeZone(),
    'yyyy-MM-dd_HH-mm-ss',
  );
  const safeName = name.replace(/[^\p{L}\p{N}\s-]/gu, '').trim().replace(/\s+/g, '-') || 'mapa';
  const fileName = 'mapa-sistemico_' + safeName + '_' + timestamp + '.png';
  return folder.createFile(Utilities.newBlob(bytes, 'image/png', fileName)).getUrl();
}

function appendSubmission(data) {
  const sheet = getOrCreateSheet(CONFIG.SHEET_NAME, SUBMISSION_HEADERS);
  const headerMap = ensureHeaders(sheet, SUBMISSION_HEADERS);
  const row = new Array(sheet.getLastColumn()).fill('');

  setByHeader(row, headerMap, 'Data', data.date);
  setByHeader(row, headerMap, 'Nome', data.name);
  setByHeader(row, headerMap, 'Contato', data.contact);
  setByHeader(row, headerMap, 'Mensagem', data.message);
  setByHeader(row, headerMap, 'Link da imagem', data.imageUrl);
  setByHeader(row, headerMap, 'Status', data.status);
  setByHeader(row, headerMap, 'Pagamento', data.paymentStatus);
  setByHeader(row, headerMap, 'ID do pagamento', data.paymentId);
  setByHeader(row, headerMap, 'Referência do pedido', data.externalReference);

  sheet.appendRow(row);
}

function upsertPayment(data) {
  const sheet = getOrCreateSheet(CONFIG.PAYMENTS_SHEET_NAME, PAYMENT_HEADERS);
  const headerMap = ensureHeaders(sheet, PAYMENT_HEADERS);
  const existing = findPayment(data.paymentId, sheet, headerMap);
  const rowNumber = existing ? existing.row : sheet.getLastRow() + 1;
  const row = existing
    ? sheet.getRange(rowNumber, 1, 1, sheet.getLastColumn()).getValues()[0]
    : new Array(sheet.getLastColumn()).fill('');

  setByHeader(row, headerMap, 'ID do pagamento', data.paymentId);
  setByHeader(row, headerMap, 'Referência do pedido', data.externalReference);
  setByHeader(row, headerMap, 'Status', data.status);
  setByHeader(row, headerMap, 'Valor', data.amount);
  setByHeader(row, headerMap, 'Moeda', data.currency);
  setByHeader(row, headerMap, 'Última atualização', data.updatedAt);
  if (!existing) setByHeader(row, headerMap, 'Utilizado', 'Não');

  sheet.getRange(rowNumber, 1, 1, row.length).setValues([row]);
}

function findPayment(paymentId, providedSheet, providedHeaderMap) {
  const sheet = providedSheet || getOrCreateSheet(CONFIG.PAYMENTS_SHEET_NAME, PAYMENT_HEADERS);
  const headerMap = providedHeaderMap || ensureHeaders(sheet, PAYMENT_HEADERS);
  if (sheet.getLastRow() < 2) return null;

  const values = sheet.getRange(2, 1, sheet.getLastRow() - 1, sheet.getLastColumn()).getValues();
  const idIndex = headerMap['ID do pagamento'];

  for (let index = 0; index < values.length; index += 1) {
    if (String(values[index][idIndex] || '') === String(paymentId)) {
      return {
        row: index + 2,
        paymentId: String(values[index][idIndex] || ''),
        externalReference: String(values[index][headerMap['Referência do pedido']] || ''),
        status: String(values[index][headerMap.Status] || ''),
        used: String(values[index][headerMap.Utilizado] || ''),
      };
    }
  }

  return null;
}

function markPaymentUsed(rowNumber) {
  const sheet = getOrCreateSheet(CONFIG.PAYMENTS_SHEET_NAME, PAYMENT_HEADERS);
  const headerMap = ensureHeaders(sheet, PAYMENT_HEADERS);
  sheet.getRange(rowNumber, headerMap.Utilizado + 1).setValue('Sim');
  sheet.getRange(rowNumber, headerMap['Data de uso'] + 1).setValue(new Date());
}

function getOrCreateSheet(name, headers) {
  const spreadsheet = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  let sheet = spreadsheet.getSheetByName(name);
  if (!sheet) sheet = spreadsheet.insertSheet(name);
  ensureHeaders(sheet, headers);
  return sheet;
}

function ensureHeaders(sheet, requiredHeaders) {
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, requiredHeaders.length).setValues([requiredHeaders]);
  }

  let current = sheet.getRange(1, 1, 1, Math.max(1, sheet.getLastColumn())).getValues()[0];
  requiredHeaders.forEach(function(header) {
    if (current.indexOf(header) === -1) {
      sheet.getRange(1, current.length + 1).setValue(header);
      current.push(header);
    }
  });

  const map = {};
  current.forEach(function(header, index) {
    map[String(header)] = index;
  });
  return map;
}

function setByHeader(row, headerMap, header, value) {
  row[headerMap[header]] = value;
}

function addBase64Padding(value) {
  const remainder = value.length % 4;
  return remainder ? value + '='.repeat(4 - remainder) : value;
}

function bytesToHex(bytes) {
  return bytes.map(function(value) {
    return ('0' + ((value + 256) % 256).toString(16)).slice(-2);
  }).join('');
}

function constantTimeEquals(left, right) {
  left = String(left || '');
  right = String(right || '');
  if (left.length !== right.length) return false;
  let diff = 0;
  for (let index = 0; index < left.length; index += 1) {
    diff |= left.charCodeAt(index) ^ right.charCodeAt(index);
  }
  return diff === 0;
}

function respond(body) {
  return ContentService.createTextOutput(JSON.stringify(body))
    .setMimeType(ContentService.MimeType.JSON);
}
